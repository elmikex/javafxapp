package com.solucionfactible.alerts.commons;

import java.io.Serializable;

/**
 *
 * @author Miguel Sandoval <msandoval@solucionfactible.com>
 */
public class ApplicationAlert implements Serializable {

    String applicationId;
    String subject;
    String body;
    Throwable throwable;

    public ApplicationAlert(String applicationId, String subject, String body, Throwable throwable) {
        this.applicationId = applicationId;
        this.subject = subject;
        this.body = body;
        this.throwable = throwable;
    }

    public String getApplicationId() {
        return applicationId;
    }
    
    public String getSubject() {
        return subject;
    }

    public String getBody() {
        return body;
    }

    public Throwable getThrowable() {
        return throwable;
    }

}
