package com.solucionfactible.alerts.commons;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Fernando Campos <fcampos@solucionfactible.com>
 */
public class JmsConnection {

    private static JmsConnection instance;
    private Connection connection;
    private Session jmsSession;
    private MessageProducer producer;
    private MessageConsumer consumer;

    public static synchronized JmsConnection getInstance() throws NamingException, JMSException {
        if (instance == null) {
            instance = new JmsConnection();
        }
        return instance;
    }
    
    public static synchronized boolean hasInstance(){
        return !(instance==null);
    }

    private JmsConnection() throws NamingException, JMSException {
        Properties properties = new Properties();
        properties.put(InitialContext.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        properties.put(InitialContext.PROVIDER_URL, "localhost:1099");
        properties.put(Context.URL_PKG_PREFIXES, "org.jboss.naming");
        InitialContext iniCtx = new InitialContext(properties);
        ConnectionFactory cf = (ConnectionFactory) iniCtx.lookup("ConnectionFactory");
        connection = cf.createConnection();
        jmsSession = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        connection.start();
        Queue queue = jmsSession.createQueue("AlertMessages");
        producer = jmsSession.createProducer(queue);
        consumer = jmsSession.createConsumer(queue);
        System.out.println("CONEXION JMS CREADA");
    }

    public void closeConnection() {
        try {
            if (producer != null) {
                producer.close();
                producer = null;
                System.out.println("producer cerrado");
            }
            if (consumer != null) {
                consumer.close();
                consumer = null;
                System.out.println("consumer cerrado");
            }
            if (jmsSession != null) {
                jmsSession.close();
                jmsSession = null;
                System.out.println("session cerrado");
            }
            if (connection != null) {
                connection.stop();
                connection.close();
                connection = null;
                System.out.println("conexion cerrado");
            }

            instance = null;
            
        } catch (JMSException ex) {
            Logger.getLogger(JmsConnection.class.getName()).log(Level.SEVERE, "No se pudo cerrar la conexion", ex);
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public Session getJmsSession() {
        return jmsSession;
    }

    public MessageProducer getProducer() {
        return producer;
    }

    public MessageConsumer getConsumer() {
        return consumer;
    }


}
