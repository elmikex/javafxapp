package com.solucionfactible.alerts;

import com.solucionfactible.alerts.commons.ApplicationAlert;
import com.solucionfactible.alerts.commons.JmsConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PreDestroy;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.ObjectMessage;
import javax.naming.NamingException;
import org.jboss.ejb3.annotation.Depends;
import org.jboss.ejb3.annotation.ResourceAdapter;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author Miguel Sandoval <msandoval@solucionfactible.com>
 */
@MessageDriven(name = "AlertConsumer",
        activationConfig = {
            @ActivationConfigProperty(propertyName = "cronTrigger", propertyValue = "*/10 * * ? * *")
        })
@ResourceAdapter("quartz-ra.rar")
@Depends({
    "org.hornetq:module=JMS,name=\"NettyConnectionFactory\",type=ConnectionFactory",
    "org.hornetq:module=JMS,name=\"InVMConnectionFactory\",type=ConnectionFactory",
    "org.hornetq:module=JMS,name=\"NettyThroughputConnectionFactory\",type=ConnectionFactory"
})
public class AlertConsumerJob implements Job {

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        System.out.println("Ejecución de AlertConsumer...");
        AlertConsumer ac = new AlertConsumer();
        try {
            ArrayList<ApplicationAlert> alerts = ac.consumeAlerts();
            System.out.println("----------------------------------------------------------------------------------------------");
            for(ApplicationAlert alert : alerts){
                System.out.println("Received alert: "+alert.getSubject());
                System.out.println(alert.getBody());
            }
            System.out.println("----------------------------------------------------------------------------------------------");
        } catch (Exception ex) {
            Logger.getLogger(AlertConsumerJob.class.getName()).log(Level.SEVERE, null, ex);
        }

    }


//    @PreDestroy
//    public void predestroy(){
//        System.out.println("==================Destroyed......");
//            Jms.closeConnection();
//
//    }
}
