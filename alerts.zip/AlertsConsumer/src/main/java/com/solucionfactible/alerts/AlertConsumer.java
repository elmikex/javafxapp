package com.solucionfactible.alerts;

import com.solucionfactible.alerts.commons.ApplicationAlert;
import com.solucionfactible.alerts.commons.JmsConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.ObjectMessage;
import javax.naming.NamingException;

/**
 *
 * @author Miguel Sandoval <msandoval@solucionfactible.com>
 */
public class AlertConsumer {

    public ArrayList<ApplicationAlert> consumeAlerts() throws Exception {
        ArrayList<ApplicationAlert> alerts = new ArrayList();
        try {
            JmsConnection jmsConnection = JmsConnection.getInstance();
            MessageConsumer messageConsumer = jmsConnection.getConsumer();
            Message messageReceived = null;

            while ((messageReceived = messageConsumer.receive(1)) != null) {
                if (messageReceived instanceof ObjectMessage) {
                    ObjectMessage oMessage = (ObjectMessage) messageReceived;
                    if (oMessage.getObject() instanceof ApplicationAlert) {
                        ApplicationAlert alert = (ApplicationAlert) oMessage.getObject();
                        alerts.add(alert);
                    }
                }
            }
            return alerts;
        } catch (NamingException ex) {
            Logger.getLogger(AlertConsumerJob.class.getName()).log(Level.SEVERE, null, ex);
            throw new Exception(ex);
        } catch (JMSException ex) {
            Logger.getLogger(AlertConsumer.class.getName()).log(Level.SEVERE, null, ex);
            throw new Exception(ex);
        }
        
    }
}
