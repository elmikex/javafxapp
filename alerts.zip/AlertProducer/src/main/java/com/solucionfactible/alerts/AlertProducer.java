package com.solucionfactible.alerts;

import com.solucionfactible.alerts.commons.ApplicationAlert;
import com.solucionfactible.alerts.commons.JmsConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.naming.NamingException;

/**
 *
 * @author Fernando Campos <fcampos@solucionfactible.com>
 */
public class AlertProducer {

    public boolean produceAlert(ApplicationAlert alert) {
        try {
            JmsConnection jmsConnection = JmsConnection.getInstance();
            MessageProducer producer = jmsConnection.getProducer();
            Session jmsSession = jmsConnection.getJmsSession();

            ObjectMessage omessage = jmsSession.createObjectMessage();
            omessage.setObject(alert);
            producer.send(omessage);
            System.out.println("Sent message: " + alert.getSubject());
            System.out.flush();
            return true;
        } catch (NamingException ex) {
            Logger.getLogger(AlertProducer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JMSException ex) {
            Logger.getLogger(AlertProducer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
