package com.solucionfactible.alerts;

import com.solucionfactible.alerts.commons.ApplicationAlert;
import javax.annotation.PreDestroy;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import org.jboss.ejb3.annotation.Depends;
import org.jboss.ejb3.annotation.ResourceAdapter;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author Fernando Campos <fcampos@solucionfactible.com>
 */
@MessageDriven(name = "Sender",
        activationConfig = {
            @ActivationConfigProperty(propertyName = "cronTrigger", propertyValue = "*/3 * * ? * *")
        })
@ResourceAdapter("quartz-ra.rar")
@Depends({
    "org.hornetq:module=JMS,name=\"NettyConnectionFactory\",type=ConnectionFactory",
    "org.hornetq:module=JMS,name=\"InVMConnectionFactory\",type=ConnectionFactory",
    "org.hornetq:module=JMS,name=\"NettyThroughputConnectionFactory\",type=ConnectionFactory"
})
public class Sender implements Job {

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        System.out.println("Ejecucion del Producer=====");
        AlertProducer producer = new AlertProducer();
        Throwable throwable = new Throwable("Truena!!!");
        ApplicationAlert alert = new ApplicationAlert("007", "solucion factible", "fallo", throwable);
        producer.produceAlert(alert);
    }

    @PreDestroy
    public void predestroy() {
        System.out.println("Destroy!!!! inserter");

    }
}
